import './App.css'
import img from './assets/e-digital.jpeg'

function ContainerOne() {
  return (
    <>
      <div className='container'>
        <h1 className='title'>Slay your EDI</h1>
        <h2 className='titleTwo'>Integreate Faster</h2>
        <p className='para'>
          Lorem, ipsum dolor sit amet consectetur adipisicing elit. Iste ea
          ducimus, atque assumenda sit libero, vero facere inventore expedita
          ab, qui animi ullam aspernatur fugit! Doloremque accusamus quo
          tempora. Minus!
        </p>
        <button className='btn1'>Schedule of free demo</button>
      </div>
      <div>
        <img src={img} className='img1'></img>
      </div>
    </>
  )
}

export default ContainerOne
