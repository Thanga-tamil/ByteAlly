import './App.css'
function NavBar() {
  let NavContent = [
    'Zenbridge',
    'About Us',
    'Products',
    'Solution',
    'Pricing',
    'Developers',
    'Resource ',
  ]

  let show = NavContent.map((val, i) => (
    <>
      <div className='navLi' key={i}>
        {val}
      </div>
    </>
  ))

  const log = () => {
    return (
      <>
        <div>
          <form action='sumbit'>
            <label htmlFor=''>name</label>
          </form>
        </div>
      </>
    )
  }
  return (
    <>
      {show}
      <button className='btn2' onClick={log}>
        Login
      </button>
    </>
  )
}

export default NavBar
