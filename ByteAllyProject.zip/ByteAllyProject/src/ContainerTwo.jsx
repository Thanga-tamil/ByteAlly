import img2 from './assets/envato-logo.png'
import one from './assets/one.png'
import two from './assets/two.png'
import three from './assets/three.png'
import four from './assets/four.png'
import five from './assets/five.png'

function ContainerTwo() {
  return (
    <>
      <div className='container_two'>
        <img className='img2' src={img2} alt='image' />

        <h1 className='titleConTwo'>
          Seth V, Senior Director, Operations & Logistics
        </h1>

        <p className='title_ConTwo'>
          use Zenbridge as middleware for the end to end sales cycle.The
          customer service and developer resource(s) we have partnered with have
          been exceptional
        </p>
        <h1 className='_end'>
          Not just our technology, we are loved for our too
        </h1>
      </div>
      <div className='img_Container'>
        <img src={one} alt='one' />
        <img src={two} alt='two' />
        <img src={three} alt='three' />
        <img src={four} alt='four' />
        <img src={five} alt='five' />
      </div>
    </>
  )
}

export default ContainerTwo
