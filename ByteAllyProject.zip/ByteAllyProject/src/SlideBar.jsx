function SlideBar() {
  const values = [
    'one',
    'two',
    'wayfair',
    'movies',
    'hello',
    'podium',
    'pillars',
  ]

  let slide = values.map((val, i) => (
    <div className='barVal' key={i}>
      {val}
    </div>
  ))
  return (
    <>
      <div className='barCon'>{slide}</div>
    </>
  )
}

export default SlideBar
