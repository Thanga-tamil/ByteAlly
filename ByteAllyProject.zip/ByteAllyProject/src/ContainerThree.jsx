function ContainerThree() {
  let dis = 'We are on a mission to make integration easy'
  let show =
    'An EDI platform for all retailers, suppliers, manufacturers, transportation, 3PLs & developers.'
  return (
    <>
      <div className='con_three'>
        <div className='sub_conOne'>
          <h1>{dis}</h1>
          <p>{show}</p>
        </div>

        <div className='sub_conTwo'>
          <h1>Faster & stabler integration</h1>
          <p>
            Our API eliminates EDI complexities using a very rich modern
            developer toolset, resulting in faster EDI integrations & production
            environments that are 10X stabler than typical EDI solutions.
          </p>
        </div>

        <div className='sub_conThree'>
          <h1>Faster & stabler integration</h1>
          <p>
            Our API eliminates EDI complexities using a very rich modern
            developer toolset, resulting in faster EDI integrations & production
            environments that are 10X stabler than typical EDI solutions.
          </p>
        </div>
        <div className='sub_conFour'>
          <h1>Faster & stabler integration</h1>
          <p>
            Our API eliminates EDI complexities using a very rich modern
            developer toolset, resulting in faster EDI integrations & production
            environments that are 10X stabler than typical EDI solutions.
          </p>
        </div>
      </div>
    </>
  )
}

export default ContainerThree
