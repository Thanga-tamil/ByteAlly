import './App.css'
import NavBar from './NavBar'
import ContainerOne from './ContainerOne'
import SlideBar from './SlideBar'
import ContainerTwo from './ContainerTwo'
import ContainerThree from './ContainerThree'

function App() {
  return (
    <>
      <NavBar />
      <ContainerOne />
      <SlideBar />
      <ContainerTwo />
      <ContainerThree />
    </>
  )
}

export default App
